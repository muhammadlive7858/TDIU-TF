<?php $__env->startSection('content'); ?>
    <div class="breadcrumbbar border">
        <div class="row align-items-center">
            <div class="col-md-8 col-lg-8">
                <h4 class="page-title">Group</h4>
                <div class="breadcrumb-list">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">group</a></li>
                        <li class="breadcrumb-item"><a href="table-editable.html#">list</a></li>
                    </ol>
                </div>
            </div>
            <div class="col-md-4 col-lg-4">
                <div class="widgetbar">
                    <button class="btn btn-primary-rgba"><i class="feather icon-plus mr-2"></i></button>
                </div>
            </div>
        </div>
    </div>

    <div class="contentbar">
        <!-- Start row -->
        <div class="row">
            <!-- Start col -->
            <div class="col-lg-12">
                <div class="card m-b-30">
                    <div class="card-header">
                        <h6>Group list</h6>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered" id="edit-btn">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Name</th>
                                        <th>Mentor</th>
                                        <th>Status</th>
                                        <th>BTN</th>

                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if(isset($groupEdit)): ?>
                                        <form action="<?php echo e(route('group.update', $groupEdit->id)); ?>" method="post">
                                            <?php echo method_field('PUT'); ?>
                                            <?php echo csrf_field(); ?>
                                            <tr>
                                                <td>#</td>
                                                <td><input placeholder="Group full name" value="<?php echo e($groupEdit->name); ?>"
                                                        type="text" name="name" class="form-control m-0"
                                                        required="required"></td>
                                                <td><input placeholder="Group's mentor" value="<?php echo e($groupEdit->mentor_id); ?>"
                                                        type="number" name="mentor_id" class="form-control m-0"
                                                        required="required"></td>
                                                <td><input placeholder="Group's course" value="<?php echo e($groupEdit->course_id); ?>"
                                                        type="number" name="course_id" class="form-control m-0"
                                                        required="required"></td>
                                                <td><input placeholder="Desription" value="<?php echo e($groupEdit->active); ?>"
                                                        type="number" name="active" class="form-control m-0"
                                                        required="required"></td>

                                                <td><button class="btn btn-primary">Update</button></td>
                                        </form>
                                    <?php endif; ?>
                                    
                                    <form action="<?php echo e(route('group.store')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                        <tr>
                                            <td>#</td>
                                            <td><input placeholder="Group full name" type="text" name="name"
                                                    class="form-control m-0" required="required"></td>
                                            <td><input placeholder="Group's mentor" type="number" name="mentor_id"
                                                    class="form-control m-0" required="required"></td>
                                            <td><input placeholder="Group's course" type="number" name="course_id"
                                                    class="form-control m-0" required="required"></td>
                                            <td><input placeholder="Desription" type="number" name="active"
                                                    class="form-control m-0" required="required"></td>


                                            <td><button class="btn btn-primary">Create</button></td>
                                    </form>
                                    
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-lg-12">
                <div class="card m-b-30">
                    <div class="card-header">
                        <h5 class="card-title">Hamma kurslar ro'yxati</h5>
                    </div>
                    <div class="card-body">
                        <div class="table-responsive form-control">
                            <table class="table table-striped table-bordered " id="edit-btn">
                                <thead>
                                    <tr>
                                        <th>No</th>
                                        <th>Name</th>
                                        <th>Mentor</th>
                                        <th>status</th>
                                        <th>Button</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td class="seconds" scope="row"><?php echo e($group->id); ?></th>
                                            <td><?php echo e($group->name); ?></td>
                                            <td><?php echo e($group->mentor_id); ?></td>
                                            <td class="seconds"><?php echo e($group->active); ?></td>
                                            <td class="d-flex  justify-content-around">
                                                <a href="<?php echo e(route('group.edit', $group->id)); ?>" class=""><i
                                                        class="bi bi-pencil btn btn-success  "
                                                        style='border-radius:5px'>Edit</i></a>
                                                <a href="<?php echo e(route('group.show', $group->id)); ?>" class=""><i
                                                    class="bi bi-pencil btn btn-primary  "
                                                    style='border-radius:5px'>Show</i></a>
                                                <form action="<?php echo e(route('group.destroy', $group->id)); ?>" method="post"
                                                    class="" >
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('delete'); ?>
                                                    <button class="btn-danger p-2 my-1" style='border-radius:5px'
                                                        onclick="delet()"><i class="bi bi-trash-fill ">Delete</i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <h6>Kurs mavjud emas!</h6>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </div>
            </div>

            <!-- End col -->
        </div>
        <!-- End row -->
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\abbostraining\newTraininggithub\resources\views/course/show.blade.php ENDPATH**/ ?>