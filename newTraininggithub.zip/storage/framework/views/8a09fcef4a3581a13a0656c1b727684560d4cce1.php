<?php $__env->startSection('content'); ?>
<div class="breadcrumbbar border">
    <div class="row align-items-center">
        <div class="col-md-8 col-lg-8">
            <h4 class="page-title">Students</h4>
            <div class="breadcrumb-list">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="">student</a></li>
                    <li class="breadcrumb-item"><a href="table-editable.html#">ro'yxati</a></li>
                </ol>
            </div>
        </div>
        <div class="col-md-4 col-lg-4">
            <div class="widgetbar">
                <button class="btn btn-primary-rgba"><i class="feather icon-plus mr-2"></i></button>
            </div>
        </div>
    </div>
</div>

<div class="contentbar">
    <!-- Start row -->
    <div class="row">
        <!-- Start col -->
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h6>Student yaratish</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered" id="edit-btn">
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Image</th>
                                <th>Group</th>
                                <th>Course</th>
                                <th class="w-25">Email</th>
                                <th>password</th>
                                <th>BTN</th>

                              </tr>
                            </thead>
                            <tbody>
                                <?php if(isset($studentEdit)): ?>
                                    <form action="<?php echo e(route('student.update',$studentEdit->id)); ?>" method="post">
                                    <?php echo method_field('put'); ?>
                                        <?php echo csrf_field(); ?>
                                        <tr>
                                            <td>#</td>
                                            <td><input value="<?php echo e($studentEdit->full_name); ?>" type="text" name="full_name" class="form-control m-0" required="required"></td>
                                            <td><input value="<?php echo e($studentEdit->phone); ?>" type="text" name="phone" class="form-control m-0" required="required"></td>
                                            <td><input value="<?php echo e($studentEdit->image); ?>" type="text" name="image" class="form-control m-0" required="required"></td>
                                            <td>
                                                <select class="form-control" name="group_id">
                                                    <option>Group selected</option>
                                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>
                                            <td>
                                                <select class="form-control" name="group_id">
                                                    <option>Course selected</option>
                                                    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($course->id); ?>"><?php echo e($course->full_name); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </td>

                                            <td><input value="<?php echo e($studentEdit->email); ?>" type="email" name="email" class="form-control m-0" required="required"></td>
                                            <td><input  type="text" name="password" class="form-control m-0" required="required"></td>


                                            <td><button class="btn btn-primary">Update</button></td>
                                    </form>
                                <?php endif; ?>
                                
                                <form action="<?php echo e(route('student.store')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('POST'); ?>
                                    <tr>
                                        <td>#</td>
                                        <td><input type="text" name="full_name" class="form-control m-0" required="required"></td>
                                        <td><input type="text" name="phone" class="form-control m-0" required="required"></td>
                                        <td><input type="text" name="image" class="form-control m-0" required="required"></td>
                                        <td>
                                            <select class="form-control" name="group_id">
                                                <option>Group selected</option>
                                                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($group->id); ?>"><?php echo e($group->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>
                                        <td>
                                            <select class="form-control" name="group_id">
                                                <option>Course selected</option>
                                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->full_name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </td>

                                        <td><input type="email" name="email" class="form-control m-0" required="required"></td>
                                        <td><input type="text" name="password" class="form-control m-0" required="required"></td>


                                        <td><button class="btn btn-primary">Create</button></td>
                                </form>
                                
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-lg-12">
            <div class="card m-b-30">
                <div class="card-header">
                    <h5 class="card-title">Guruh studentlari ro'yxati</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive form-control">
                        <table class="table table-striped table-bordered " id="edit-btn">
                            <thead>
                              <tr>
                                <th>No</th>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Image</th>
                                <th>Group</th>
                                <th>Course</th>
                                <th class="w-25">Email</th>
                                <th>Password</th>
                                <th>Button</th>
                              </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td  class="seconds" scope="row"><?php echo e($student->id); ?></th>
                                    <td><?php echo e($student->full_name); ?></td>
                                    <td><?php echo e($student->phone); ?></td>
                                    <td class="seconds" style="width:120px;height:80px"> <image src="<?php echo e($student->image); ?>" class="w-100"> </td>
                                    <td class="seconds"><?php echo e($student->group_id); ?></td>
                                    <td class="seconds"><?php echo e($student->course_id); ?></td>
                                    <td><?php echo e($student->email); ?></td>
                                    <td><?php echo e($student->password); ?></td>
                                    <td  class="d-flex align-center justify-content-around p-2">
                                        <a href="<?php echo e(route('student.edit',$student->id)); ?>" class="m-2 p-3"><i class="bi bi-pencil btn-success w-100 p-2" style='border-radius:5px'>Edit</i></a>
                                        <form action="<?php echo e(route('student.destroy',$student->id)); ?>" method="post" class="d-flex align-center ">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                        <button class="btn-danger w-100 p-3 m-2"style='border-radius:5px' onclick="delet()"><i class="bi bi-trash-fill " >Delete</i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h6>Student mavjud emas!</h6>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- End row -->
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\abbostraining\newTraininggithub\resources\views/group/show.blade.php ENDPATH**/ ?>