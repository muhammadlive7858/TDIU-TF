<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('mentor.store')); ?>" method="POST" class="form-control py-4" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-group">
        <label for="exampleInputEmail1">Full Name</label>
        <input name="fullname" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter fullname">
        <small id="emailHelp" class="form-text text-muted">We'll never share your fullname with anyone else.</small>
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Phone</label>
        <input name="phone" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter phone">
        <small id="emailHelp" class="form-text text-muted">We'll never share your phone with anyone else.</small>
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Salary</label>
        <input name="salary" type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter salary">
        <small id="emailHelp" class="form-text text-muted">We'll never share your salary with anyone else.</small>
      </div>
      <div class="form-group">
        <label for="exampleInputEmail1">Image</label>
        <input name="image"  type="file" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter phone">
        <small id="emailHelp" class="form-text text-muted">We'll never share your image with anyone else.</small>
      </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Email address</label>
      <input name="email" type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
      <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
    </div>
    <div class="form-group">
      <label for="exampleInputPassword1">Password</label>
      <input name="password" type="password" class="form-control" id="exampleInputPassword1" placeholder="Password">
    </div>
    
    <button type="submit" class="btn btn-primary py-2">Submit</button>
  </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\OSPanel\domains\abbostraining\newTraininggithub\resources\views/mentor/create.blade.php ENDPATH**/ ?>