@extends('layouts.app')

@section('content')
<h1>salom</h1>
@endsection
